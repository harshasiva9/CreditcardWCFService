﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Ipp.Recruitment.BusinessLayer;


namespace Ipp.Recruitment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class PaymentService : IPaymentService
    {
        public const string MyId = "2a8dec5a-5f70-45a2-9e0b-b14064850de0";
        ProcessCreditCard obj;
        public string WhatsYourId()
        {
            return MyId;
        }

        /// <summary>
        /// Implemented Luhn or MOD10 algorithm: https://en.wikipedia.org/wiki/Luhn_algorithm
        /// </summary>
        /// <param name="cardNumber">0000007992739871</param>
        /// <returns>true</returns>
        public  bool IsCardNumberValid(string cardNumber)
        {
            bool isCardValid=false;
            CreditCardException exp = new CreditCardException();
            try
            {
                obj = new ProcessCreditCard();
                isCardValid = obj.LuhnAlgorithm(cardNumber.Trim());
            }
            catch (Exception ex)
            {
                exp.Title = "Error Occured at Funtion: IsCardNumberValid(cardNumber)";
                exp.ExceptionMessage = "Error occur while doing validating Credit Card function.";
                exp.InnerException = ex.InnerException.ToString(); 
                isCardValid = false;
                throw new FaultException<CreditCardException>(exp, ex.ToString());               
            }
            return isCardValid;
        }

        /// <summary>
        /// check payment amount
        /// true if amount between 99 to 99999999
        /// false if amount not between 99 to 99999999
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public bool IsValidPaymentAmount(long amount)
        {
            bool isPaymentValid = false;
            CreditCardException exp = new CreditCardException();
            try
            {
                obj = new ProcessCreditCard();
                isPaymentValid = obj.IsValidAmount(amount);
            }
            catch (Exception ex)
            {
                exp.Title = "Error Occured at Funtion: IsValidPaymentAmount(amount)";
                exp.ExceptionMessage = "Error occur while doing validating Payment amount function.";
                exp.InnerException = ex.InnerException.ToString(); 
                isPaymentValid = false;
                throw new FaultException<CreditCardException>(exp, ex.ToString());  
            }
            return isPaymentValid;
        }

        /// <summary>
        /// Check credit card number according to uhn or MOD10 algorithm: https://en.wikipedia.org/wiki/Luhn_algorithm
        /// check the Expiration date according to current date
        /// </summary>
        /// <param name="cardNumber">0000007992739871</param>
        /// <param name="expiryMonth">1</param>
        /// <param name="expiryYear">2017</param>
        /// <returns></returns>
        public bool CanMakePaymentWithCard(string cardNumber, int expiryMonth, int expiryYear)
        {
            bool isValid = false;
            CreditCardException exp = new CreditCardException();
            try
            {
                obj = new ProcessCreditCard();
                if(obj.LuhnAlgorithm(cardNumber.Trim()) && obj.CheckExpireDate(expiryMonth,expiryYear))
                    isValid = true;
            }
            catch (Exception ex)
            {
                exp.Title = "Error Occured at Funtion: CanMakePaymentWithCard(cardNumber,expiryMonth,expiryYear)";
                exp.ExceptionMessage = "Error occur while doing validating Expiry date or Validating Card number function.";
                exp.InnerException = ex.InnerException.ToString(); 
                isValid = false;
                throw new FaultException<CreditCardException>(exp, ex.ToString());  
            }
            return isValid;
        }
        
    }
}
