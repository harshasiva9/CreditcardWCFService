﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace Ipp.Recruitment.BusinessLayer
{
    public class ProcessCreditCard
    {
        /// <summary>
        /// Credit CardLength should be 
        /// </summary>
        public const int cardLength = 16;
        public const int minAmount = 99;
        public const long maxAmount = 99999999;

        /// <summary>
        /// Check Credit card number according to  Mod-10/LUHN  Algorithm
        /// </summary>
        /// <param name="cardNumber">0000007992739871</param>
        /// <returns>true</returns>
        public bool LuhnAlgorithm(string cardNumber)
        {           
            bool isValid = false;
            if (IsCreditCardValidDigits(cardNumber))
            {
                int totalSumOfDigits = 0;
                int mod10 = 0;
                string checkDigit = string.Empty;
                string nonCheckDigit = string.Empty;
                string _mod10 = string.Empty;
                string _totalSumOfDigits = string.Empty;

                if (cardLength == cardNumber.Length)
                {
                    for (int i = 0; i < 16; i++)
                    {
                        //check the even number order from right to left
                        if (i % 2 == 0) 
                        {
                            totalSumOfDigits += Convert.ToInt32(cardNumber[i].ToString());
                        }
                        // odd number order from right to left
                        // if number * 2 > 9 => then sum the digits of the products 
                            //example : number=8 =>  if(8*2 > 9 ) => 16 => 1+6 => 7
                        //else if number * 2 < 9
                            // consider number as product
                        else 
                        {
                            int doubleDigit = Convert.ToInt32(cardNumber[i].ToString()) * 2;
                            if (doubleDigit > 9)
                            {
                                int sumdoubleDigit = 0;
                                string _doubleDigit = doubleDigit.ToString();
                                for (int j = 0; j < _doubleDigit.Length; j++)
                                {
                                    sumdoubleDigit += Convert.ToInt32(_doubleDigit[j].ToString());
                                }
                                totalSumOfDigits += sumdoubleDigit;
                            }
                            else
                            {
                                totalSumOfDigits += doubleDigit;
                            }
                        }
                        _totalSumOfDigits = Convert.ToString(totalSumOfDigits);

                    }

                    mod10 = totalSumOfDigits * 9;
                    _mod10 = Convert.ToString(mod10);

                    // checkDigit = >last digit of mod10  
                    checkDigit = Convert.ToString(_mod10[_mod10.Length - 1]);
                    //_totalSumOfDigits => last digit of total sum of digits
                    nonCheckDigit = Convert.ToString(_totalSumOfDigits[_totalSumOfDigits.Length - 1]);

                    int isValidDigit = 10 - Convert.ToInt32(nonCheckDigit);

                    //if isValidDigit = checkDigit => then its valid crdit card number
                    if (isValidDigit == Convert.ToInt32(checkDigit))
                        isValid = true;

                }
            }
            return isValid;
        }

        /// <summary>
        /// cardNumber should contain only numeric digits
        /// </summary>
        /// <param name="cardNumber">*$12345678123467</param>
        /// <returns>false</returns>
      public  bool IsCreditCardValidDigits(string cardNumber)
        {
            foreach (char c in cardNumber)
            {
                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }

      /// <summary>
      /// amount should be between 99 to 99999999
      /// </summary>
      /// <param name="amount">99999998</param>
      /// <returns>true</returns>
      public bool IsValidAmount(long amount)
      {
          if (amount > minAmount && amount < maxAmount)
              return true;
          else
              return false;
      }

        /// <summary>
        /// check expiration date
        /// </summary>
        /// <param name="expiryMonth">9</param>
        /// <param name="expiryYear">2017</param>
        /// <returns>true</returns>
      public bool CheckExpireDate(int expiryMonth, int expiryYear)
      {
          var monthCheck = new Regex(@"^(0[1-9]|1[0-2])$");
          var yearCheck = new Regex(@"^20[0-9]{2}$");
          int currentMonth = DateTime.Now.Month;
          int currentYear = DateTime.Now.Year;
          bool isValid = true;

          if (monthCheck.IsMatch(Convert.ToString(expiryMonth)) || yearCheck.IsMatch(Convert.ToString(expiryYear)))
          {
              if ((expiryYear < currentYear)
                    || (expiryYear == currentYear & (currentMonth > expiryMonth)))
              { isValid = false; }
          }
          else
          {
              isValid = false; 
          }
          return isValid;
      }
        
    }

}